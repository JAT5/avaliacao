package com.example.avaliacao;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnReservar1;
    private Button btnReservar2;
    private Button btnReservar3;
    private Button btnReservar4;
    private Button btnReservar5;
    private Button btnReservar6;
    private Button btnReservar7;
    private Button btnReservar8;
    private Button btnReservar9;
    private Button btnLiberar;
    private Button btnSalvar;
    private Button btnReservarTudo;

    boolean flag;
    boolean flag1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnReservar1    = findViewById(R.id.btnMesa1);
        btnReservar2    = findViewById(R.id.btnMesa2);
        btnReservar3    = findViewById(R.id.btnMesa3);
        btnReservar4    = findViewById(R.id.btnMesa4);
        btnReservar5    = findViewById(R.id.btnMesa5);
        btnReservar6    = findViewById(R.id.btnMesa6);
        btnReservar7    = findViewById(R.id.btnMesa7);
        btnReservar8    = findViewById(R.id.btnMesa8);
        btnReservar9    = findViewById(R.id.btnMesa9);
        btnSalvar       = findViewById(R.id.btnSalvar);
        btnReservarTudo = findViewById(R.id.btnReservarTudo);
        btnLiberar      = findViewById(R.id.btnLiberar);

        flag = false;

        mainControl();

    }


    public void mainControl(){

        btnReservar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 1 );

            }
        });

        btnReservar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 2 );

            }
        });

        btnReservar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 3 );

            }
        });

        btnReservar4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 4 );

            }
        });

        btnReservar5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 5 );

            }
        });

        btnReservar6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 6 );

            }
        });

        btnReservar7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 7 );

            }
        });

        btnReservar8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 8 );

            }
        });

        btnReservar9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = true;
                changeColor( 9 );

            }
        });




        btnLiberar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                EditText edit = (EditText)findViewById(R.id.inputMesa);
                String text = edit.getText().toString();

                switch (text){
                    case "1": flag =  false;
                            changeColor(1);
                            break;
                    case "2": flag =  false;
                            changeColor(2);
                            break;
                    case "3": flag =  false;
                            changeColor(3);
                            break;
                    case "4": flag =  false;
                            changeColor(4);
                            break;
                    case "5": flag =  false;
                            changeColor(5);
                            break;
                    case "6": flag =  false;
                            changeColor(6);
                            break;
                    case "7": flag =  false;
                            changeColor(7);
                            break;
                    case "8": flag =  false;
                            changeColor(8);
                            break;
                    case "9": flag =  false;
                            changeColor(9);
                            break;
                    default:
                            break;


                }

            }

        });

        btnReservarTudo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag1 = false;

                for( int i=1; i<=9; i++){

                    LinearLayout cor;
                    String mesa = "linearMesa"+i;
                    int mesaID;
                    mesaID = getResources().getIdentifier(mesa, "id", getPackageName());
                    cor = ((LinearLayout) findViewById(mesaID));

                    Button btn;
                    String reserva = "btnMesa"+i;
                    int reservarID;
                    reservarID = getResources().getIdentifier(reserva, "id", getPackageName());
                    btn = ((Button) findViewById(reservarID));

                    if(btn.isEnabled()) flag1 = true;

                    cor.setBackgroundColor(getResources().getColor(R.color.colorReservado));
                    btn.setEnabled(false);

                }

                if( !flag1 ){

                    String hint = getString(R.string.hintReservado);
                    Toast.makeText(MainActivity.this, hint, Toast.LENGTH_LONG).show();

                }

            }

        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }

        });



    }


    public String changeColor( int id ) {

        LinearLayout cor;
        String mesa = "linearMesa"+id;
        int mesaID;
        mesaID = getResources().getIdentifier(mesa, "id", getPackageName());
        cor = ((LinearLayout) findViewById(mesaID));

        Button btn;
        String reserva = "btnMesa"+id;
        int reservarID;
        reservarID = getResources().getIdentifier(reserva, "id", getPackageName());
        btn = ((Button) findViewById(reservarID));

        if( flag ){

            cor.setBackgroundColor(getResources().getColor(R.color.colorReservado));
            btn.setEnabled(false);
            return "true";

        } else {

            if(btn.isEnabled()){

                String hint = getString(R.string.hintDisponivel);
                hint = hint.replace("X", Integer.toString(id) );
                Toast.makeText(MainActivity.this, hint, Toast.LENGTH_LONG).show();

            }
            cor.setBackgroundColor(getResources().getColor(R.color.colorBlue));
            btn.setEnabled(true);
            return "false";

        }

    }



}
